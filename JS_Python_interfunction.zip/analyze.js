const fs = require("fs");
const path = require("path");
const parser = require("@babel/parser");
const traverse = require("@babel/traverse").default;
const t = require("@babel/types");

let functionId = 1;
const functionMap = new Map();
const uniqueFunctions = [];
const functionCalls = [];

function getFileContent(filePath) {
  return fs.readFileSync(filePath, "utf-8");
}

function parseFile(filePath) {
  const code = getFileContent(filePath);
  return parser.parse(code, {
    sourceType: "module",
    plugins: ["jsx", "typescript"], // Optional if you're using JSX/TS
  });
}

function analyzeAST(ast, filePath) {
  const stack = [];

  traverse(ast, {
    enter(path) {
      if (
        path.isFunctionDeclaration() ||
        path.isFunctionExpression() ||
        path.isArrowFunctionExpression() ||
        path.isClassMethod()
      ) {
        const funcName = path.node.id?.name || path.node.key?.name || "anonymous_" + functionId;
        const parentClass = path.findParent(p => t.isClassDeclaration(p.node))?.node?.id?.name || null;
        const parentFunction = stack.length ? stack[stack.length - 1] : null;
        const params = path.node.params || [];

        const paramTypes = params.map(p => (p.type === "Identifier" ? "unknown" : p.type));
        const funcObj = {
  id: functionId,
  name: funcName,
  file: filePath.split("/").pop(),
  path: filePath,
  language: "JavaScript",
  parameters: {
    count: params.length,
    types: paramTypes
  },
  parentClass,
  parentFunction: parentFunction?.name || null,
  startLine: path.node.loc?.start.line || null,
  endLine: path.node.loc?.end.line || null
};


        functionMap.set(path.node, funcObj);
        uniqueFunctions.push(funcObj);
        stack.push(funcObj);
        functionId++;
      }

      // Track function calls
      if (path.isCallExpression()) {
        const callerFunc = stack[stack.length - 1];
        if (!callerFunc) return;

        const callee = path.get("callee");
        const calleeName = callee.isIdentifier()
          ? callee.node.name
          : callee.isMemberExpression()
          ? callee.node.property.name
          : "unknown";

        const calleeFunc = uniqueFunctions.find(f => f.name === calleeName);

        functionCalls.push({
          callerId: callerFunc.id,
          calleeId: calleeFunc?.id || null,
          isInsideIfElseOrSwitch: !!path.findParent(p => p.isIfStatement() || p.isSwitchStatement()),
          isInsideLoopOrEnvironment: !!path.findParent(p =>
            p.isWhileStatement() || p.isForStatement() || p.isDoWhileStatement()
          ),
          isDifferentLanguage: false,
          isDifferentModule: false,
          isInsideClass: !!path.findParent(p => p.isClassDeclaration()),
          isInsideFunction: !!path.findParent(p => p.isFunction())
        });
      }
    },
    exit(path) {
      if (
        path.isFunctionDeclaration() ||
        path.isFunctionExpression() ||
        path.isArrowFunctionExpression() ||
        path.isClassMethod()
      ) {
        stack.pop();
      }
    }
  });
}

function analyzeDirectory(dirPath) {
  const files = fs.readdirSync(dirPath);
  files.forEach(file => {
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isFile() && file.endsWith(".js")) {
      const ast = parseFile(fullPath);
      analyzeAST(ast, fullPath);
    }
  });
}

// Analyze everything in /src
analyzeDirectory(path.join(__dirname, "./test/"));

// Output JSON
const output = {
  uniqueFunctions,
  functionCalls
};

fs.writeFileSync("output.json", JSON.stringify(output, null, 2));
console.log("✅ Functional flow written to output.json");
