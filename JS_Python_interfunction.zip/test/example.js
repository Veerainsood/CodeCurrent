function greet(name) {
  console.log("Hello, " + name);
}

greet("World");

