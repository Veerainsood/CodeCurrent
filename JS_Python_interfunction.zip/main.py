import subprocess

try:
    result = subprocess.run(
        ["node", "analyze.js"],
        capture_output=True,
        text=True,
        check=True
    )
    print(result.stdout)
except subprocess.CalledProcessError as e:
    print("Error running analyze.js:")
    print(e.stderr)

